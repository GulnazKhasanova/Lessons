const products = [
    {id:1, title:'t_shirt1', price:52, amounts:4},
    {id:2, title:'t_shirt2', price:150, amounts:2}
];

const renderProduct = (title, price, amount, id) => {
  return `<div class="cart_basket_img">
                <img src="../src/assets/img/t_shirt${id}.jpg" alt="" class="img_basket">
                    <div class="text_img_basket">
                        <p> ${title}<br> <span>${amount} x ${price}</span>
                        </p>
                        <p>
                           <i class="far fa-star star_color"></i>
                           <i class="far fa-star star_color"></i>
                           <i class="far fa-star star_color"></i>
                           <i class="far fa-star star_color"></i>
                           <i class="far fa-star star_color"></i>

                        </p>
<a href="" class=" fas fa-times-circle" name="remov" data-id="${id}" ></a>
                    </div>
        </div>` 
};

const productPage = list => {
    const productList = list.map(item => renderProduct(item.title, item.price, item.amounts, item.id));
    document.querySelector('.basket_inner').innerHTML = productList;
    
}; 
productPage(products);