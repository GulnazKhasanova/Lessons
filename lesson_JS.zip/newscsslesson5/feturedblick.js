let TITLES = [ 'PEOPLE T-SHIRT',
    'POTATO PEOPLE T-SHIRT',
    'TOMATO PEOPLE T-SHIRT',
    'ORANGE PEOPLE T-SHIRT',
    'LEMON PEOPLE T-SHIRT',
    'KIWI PEOPLE T-SHIRT',
    'GRAPES PEOPLE T-SHIRT',
    'COCONUT PEOPLE T-SHIRT'
];
let PRICES = [ 52, 150, 780, 84, 26, 120, 253, 75];

const catalog = {
    items: [],
    container: null,
    init() {
        this.container = document.querySelector('#catalog');
        this.items = getItems();
        this._render();
    },
    _render() {
        let htmlStr = '';
        this.items.forEach(item => {
            htmlStr += `<div class="row_item_card"><div class="item_card">
                        <div class="item_img">
                            <img src="img/rectangle_5_copy_1193.jpg" alt="" class="img_blockitem">
                            <div class="layer">
                                <a href="" class="add_to_cart1">Add to Cart</a>
                            </div>
                        </div>
                        <div class="title_blockitem">
                            <p class="text_blockitem">${item.productName}</p>
                            <p class="price_blockitem">$${item.productPrice}</p>
                        </div>
                        </div>
                    </div>`
        });
    
    this.container.innerHTML = htmlStr;
    }
}
catalog.init();

function getItems() {
    arr = [];
    for (let i = 0; i < TITLES.length; i++) {
       arr.push(createItems(i)) 
    }
    
    return arr;
}
function createItems(index) {
    return {
        productName: TITLES[index],
        productPrice: PRICES[index],
        productId: 'prod_${index + 1}'
    }
}